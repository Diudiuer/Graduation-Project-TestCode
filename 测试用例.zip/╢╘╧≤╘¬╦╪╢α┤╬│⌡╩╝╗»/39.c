struct inner {
  int a;
  int b;
};

struct outer {
  int x;
  struct {
    int a;
    int b;
  } i;
};

struct outer s = {
  .x = 42,
  .i.a = 1,
  .i.b = 2,
  .i.a = 3,  // Non-compliant: Initializing different members 'a' and 'b' of anonymous struct
  .i.b = 4,
  .i.a = 5  // Non-compliant: Initializing member 'a' again
};