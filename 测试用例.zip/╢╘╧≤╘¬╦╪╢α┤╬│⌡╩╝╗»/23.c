struct mystruct {
  int x;
  struct {
    int a;
    int b;
    int a;
  };
};

struct mystruct s = {
  .x = 42,
  .a = 1,
  .b = 2,
  .a = 3  // Non-compliant: Initializing member 'a' twice
};