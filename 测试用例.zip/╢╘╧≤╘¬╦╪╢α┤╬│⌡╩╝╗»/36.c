union myunion {
  int a;
  float b;
};

struct mystruct {
  int x;
  union myunion u;
};

struct mystruct s = {
  .x = 42,
  .u.a = 1,
  .u.b = 2.0,
  .u.a = 3,  // Non-compliant: Initializing different members 'a' and 'b' of named union 'u'
  .u.b = 4.0
};