struct inner {
  int a;
  int b;
};

struct outer {
  int x;
  struct inner i1;
  struct inner i2;
};

struct outer s = {
  .x = 42,
  .i1 = {.a = 1, .b = 2},
  .i2 = {.a = 3, .b = 4},
  .i1.a = 5  // Non-compliant: Initializing member 'a' of 'i1' twice
};