struct mystruct {
  int x;
  int y;
};

struct mystruct s = {{1, 2}, {3, 4}}; // Non-compliant: Initializing struct with multiple '{}' objects