union {
  int a;
  float b;
} u = {
  .a = 1,
  .b = 2.0,
  .a = 3  // Non-compliant: Initializing member 'a' twice
};