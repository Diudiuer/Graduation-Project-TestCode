struct mystruct {
  int x;
  union {
    int a;
    int b;
  };
  union {
    int c;
    int a;
  };
};

struct mystruct s = {
  .x = 42,
  .a = 1,
  .b = 2,
  .c = 3,
  .a = 4  // Non-compliant: Initializing member 'a' twice
};