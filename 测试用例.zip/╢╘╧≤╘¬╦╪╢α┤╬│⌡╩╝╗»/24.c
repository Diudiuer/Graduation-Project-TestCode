struct mystruct {
  int x;
  union {
    int a;
    float b;
  };
};

struct mystruct s = {
  .x = 42,
  .a = 1,
  .b = 2.0,
  .a = 3  // Non-compliant: Initializing member 'a' twice
};