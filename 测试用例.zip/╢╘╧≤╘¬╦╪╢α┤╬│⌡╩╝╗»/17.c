#include <stdio.h>

typedef struct {
    int x;
    float y;
} point;

point p = {.x = 1, .y = 2.5}; // 对象元素x和y分别初始化为1和2.5，重复初始化了元素x

int main() {
    printf("Before modification: x=%d, y=%f\n", p.x, p.y);

    // 对象元素x再次初始化为3，类型改为float
    typedef struct {
        float x;
        float y;
    } point2;

    point2 p2 = {.x = 3.0, .y = 4.0, .x = 5.0};

    printf("After modification: x=%f, y=%f\n", p2.x, p2.y);

    return 0;
}