
#include <stdio.h>

typedef struct {
    int a;
    float b;
    char c;
} mystruct;

mystruct s = {.a = 1, .b = 2.5, .c = 'a'}; // 结构体成员类型为int、float、char，重复初始化了成员a

int main() {
    printf("%d %f %c\n", s.a, s.b, s.c);

    // 修改结构体成员类型为float、char、double，并重复初始化成员c
    typedef struct {
        float a;
        char b;
        double c;
    } mystruct2;

    mystruct2 s2 = {.a = 1.2, .b = 'x', .c = 3.4, .c = 5.6};

    printf("%f %c %lf\n", s2.a, s2.b, s2.c);

    return 0;
}