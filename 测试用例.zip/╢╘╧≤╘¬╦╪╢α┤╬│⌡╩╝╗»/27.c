struct mystruct {
  unsigned int flag1 : 1;
  unsigned int flag2 : 1;
};

struct mystruct s = {
  .flag1 = 1,
  .flag2 = 0,
  .flag1 = 0,  // Non-compliant: Initializing different bit-fields 'flag1' and 'flag2'
  .flag2 = 1
};