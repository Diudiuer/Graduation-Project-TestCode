struct {
  int a;
  int b;
} arr[2] = {
  {.a = 1, .b = 2},
  {.a = 3, .b = 4, .a = 5} // Non-compliant: Initializing member 'a' twice
};