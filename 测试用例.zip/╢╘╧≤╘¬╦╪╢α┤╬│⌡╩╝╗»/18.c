#include <stdio.h>

typedef struct {
    int x;
    int y;
} point;

point p = {.x = 1, .y = 2}; // 对象元素x和y分别初始化为1和2，重复初始化了元素x

int main() {
    printf("Before modification: x=%d, y=%d\n", p.x, p.y);

    // 对象元素x再次初始化为3
    point p2 = {.x = 3, .y = 4, .x = 5};

    printf("After modification: x=%d, y=%d\n", p2.x, p2.y);

    return 0;
}