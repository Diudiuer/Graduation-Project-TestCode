#include <stdio.h>
#include <string.h>

typedef struct {
    int id;
    char name[10];
} person;

person p = {.id = 1, .name = "JohnDoe"}; // 结构体成员名字长度为7，重复初始化了成员name

int main() {
    printf("Before modification: id=%d, name=%s\n", p.id, p.name);

    // 修改结构体成员name长度为20，并重复初始化成员name
    typedef struct {
        int id;
        char name[20];
    } person2;

    person2 p2 = {.id = 2, .name = "JaneDoeJaneDoe"};

    printf("After modification: id=%d, name=%s\n", p2.id, p2.name);

    return 0;
}