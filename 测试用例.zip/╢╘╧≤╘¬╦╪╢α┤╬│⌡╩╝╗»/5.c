union myunion {
  int a;
  float b;
};

union myunion u = {
  .a = 1,
  .b = 2.0,
  .a = 3  // Non-compliant: Initializing member 'a' twice
};