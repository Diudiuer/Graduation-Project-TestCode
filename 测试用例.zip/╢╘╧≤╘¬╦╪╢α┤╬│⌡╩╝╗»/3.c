struct mystruct {
  int x;
  int y;
  int x;
};

struct mystruct s = {
  .x = 1,
  .y = 2,
  .x = 3  // Non-compliant: Initializing member 'x' twice
};