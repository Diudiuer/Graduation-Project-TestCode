union {
  int a;
  float b;
} u = {
  .a = 1,
  .b = 2.0,  // Non-compliant: Initializing different members 'a' and 'b' of anonymous union
  .a = 3
};