#include <stdio.h>
#include <string.h>

int main() {
    char arr[5][10] = {"apple", "banana", "orange", "peach", "pear"}; // 数组元素长度为6、6、6、6、5，重复初始化了下标为2的元素

    for (int i = 0; i < 5; i++) {
        printf("%s ", arr[i]);
    }
    printf("\n");

    // 修改数组元素长度为15，并重复初始化下标为1的元素
    char arr2[5][15] = {"apple", "bananaaaaaaa", "cherry", "peach", "pear"};

    for (int i = 0; i < 5; i++) {
        printf("%s ", arr2[i]);
    }
    printf("\n");

    return 0;
}