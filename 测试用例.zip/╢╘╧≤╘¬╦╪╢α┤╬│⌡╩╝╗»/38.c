struct inner {
  int a;
  int b;
};

struct outer {
  int x;
  struct inner i;
};

struct outer s = {
  .x = 42,
  .i.a = 1,
  .i.b = 2,
  .i.a = 3,  // Non-compliant: Initializing different members 'a' and 'b' of named struct 'i'
  .i.b = 4
};