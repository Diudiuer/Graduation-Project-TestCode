struct mystruct {
  int x;
  struct {
    int a;
    int b;
  };
};

struct mystruct s = {
  .x = 42,
  .a = 1,
  .b = 2,
  .a = 3,  // Non-compliant: Initializing different members 'a' and 'b' of anonymous struct
  .b = 4
};