struct inner {
  int a;
  int b;
};

struct outer {
  int x;
  struct inner i;
};

struct outer s = {
  .x = 42,
  .i = {.a = 1, .b = 2},
  .i.a = 3  // Non-compliant: Initializing member 'a' of 'i' twice
};