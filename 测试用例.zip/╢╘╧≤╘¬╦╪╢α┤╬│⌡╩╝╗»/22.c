#include <stdio.h>

int arr[5] = {[0] = 1, [1] = 2, [2] = 3, [2] = 4, [4] = 5}; // 数组长度为5，重复初始化了下标为2的元素

int main() {
    for (int i = 0; i < 5; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    // 修改数组类型为char，长度为3，并重复初始化下标为1的元素
    char arr2[3] = {[0] = 'a', [1] = 'b', [1] = 'c', [2] = 'd'};

    for (int i = 0; i < 3; i++) {
        printf("%c ", arr2[i]);
    }
    printf("\n");

    return 0;
}