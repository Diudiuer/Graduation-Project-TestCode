struct mystruct {
  int x;
  union {
    int a;
    float b;
  };
};

struct mystruct s = {
  .x = 42,
  .a = 1,
  .b = 2.0,  // Non-compliant: Initializing different members 'a' and 'b' of anonymous union
  .a = 3
};