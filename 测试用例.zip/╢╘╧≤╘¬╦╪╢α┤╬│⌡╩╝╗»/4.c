struct mystruct {
  unsigned int flag : 1;
};

struct mystruct s = {
  .flag = 1,
  .flag = 0  // Non-compliant: Initializing bit-field 'flag' twice
};