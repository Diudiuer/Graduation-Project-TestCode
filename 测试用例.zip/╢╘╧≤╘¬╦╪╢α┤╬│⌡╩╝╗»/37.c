struct mystruct {
  int x;
  int arr[3];
};

struct mystruct s = {
  .x = 42,
  .arr[0] = 1,
  .arr[1] = 2,
  .arr[0] = 3,  // Non-compliant: Initializing different elements of array 'arr'
  .arr[2] = 4
};