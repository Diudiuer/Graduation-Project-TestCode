struct mystruct {
  int x;
  int y;
};

struct mystruct arr[2] = {
  {.x = 1, .y = 2},
  {.x = 3, .y = 4, .x = 5} // Non-compliant: Initializing member 'x' twice
};