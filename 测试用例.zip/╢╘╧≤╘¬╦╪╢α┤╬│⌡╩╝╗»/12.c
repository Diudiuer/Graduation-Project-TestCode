struct Point {
    int x;
    int y;
};

struct Point p = {.x = 1, .y = 2, .x = 3};12
