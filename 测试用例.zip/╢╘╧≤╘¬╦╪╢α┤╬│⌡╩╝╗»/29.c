enum myenum {
  RED,
  GREEN,
  BLUE
};

struct mystruct {
  int x;
  enum myenum e;
};

struct mystruct s = {
  .x = 42,
  .e = RED,
  .e = GREEN  // Non-compliant: Initializing member 'e' twice
};