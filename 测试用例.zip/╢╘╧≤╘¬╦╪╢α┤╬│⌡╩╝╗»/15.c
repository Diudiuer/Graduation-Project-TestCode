#include <stdio.h>
#include <string.h>

typedef struct {
    int id;
    char name[10];
} person;

person p = {.id = 1, .name = "JohnDoe"}; // 对象元素id和name分别初始化为1和"JohnDoe"，重复初始化了元素name

int main() {
    printf("Before modification: id=%d, name=%s\n", p.id, p.name);

    // 对象元素name再次初始化为"JaneDoeJaneDoe"，长度为20
    typedef struct {
        int id;
        char name[20];
    } person2;

    person2 p2 = {.id = 2, .name = "JaneDoeJaneDoe"};

    printf("After modification: id=%d, name=%s\n", p2.id, p2.name);

    return 0;
}